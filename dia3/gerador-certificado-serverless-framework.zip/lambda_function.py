import sys
sys.path.insert(0, "./libs")

import json
import boto3
import os
from io import BytesIO
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm, cm
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import SimpleDocTemplate, Paragraph
from reportlab.pdfbase.pdfmetrics import stringWidth
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from PyPDF2 import PdfWriter, PdfReader

import uuid

# Layers (Camadas)
# https://github.com/keithrozario/Klayers/tree/master/deployments/python3.10

pdfmetrics.registerFont(
    TTFont('RobotoCondensed-Regular', 'fonts/RobotoCondensed-Regular.ttf')
)

modelo = 'modelos/certificado_conclusao_modelo.pdf'
fonte = 14
horas_expira = 24

cliente_ses = boto3.client('ses')
cliente_s3 = boto3.client('s3')
s3 = boto3.resource('s3')

# evento = {
#     'Records': [
#         {
#             's3': {
#                 'bucket': {
#                     'name': 'ct-cloud-prod-exemplo-s3-demo2'
#                 },
#                 'object': {
#                     'key': 'alunos_python.csv'
#                 }
#             }
#         }
#     ]
# }

def lambda_handler(event, context):

    nome_bucket = event['Records'][0]['s3']['bucket']['name']
    nome_objeto = event['Records'][0]['s3']['object']['key']

    bucket = s3.Bucket(nome_bucket)
    alunos = s3.Object(nome_bucket, nome_objeto)
    arquivo = alunos.get()
    dados_alunos = arquivo['Body'].read()
    
    dados_alunos = dados_alunos.decode('utf8')
    lista = dados_alunos.split('\n')

    for indice, linha in enumerate(lista):
        if indice == 0:
            continue
        
        colunas = linha.split(',')
        nome = colunas[0]
        email = colunas[1]
        curso = colunas[2]
        horas = colunas[3]
        data = colunas[4]

        arquivo_saida = processar_pdf(nome, curso, horas, data, bucket)

        expira_segundos = horas_expira * 3600 
        link = gerar_link(nome_bucket, arquivo_saida, expira_segundos)

        envia_email(email, nome, curso, link)

    return {
        "statusCode": 200, 
        "body": "Certificados processados com sucesso."
    }


def envia_email(email, nome, curso, link):
    
    try:
        cliente_ses.send_email(
            Source=os.getenv('EMAIL_REMETENTE'),
            Destination={
                'ToAddresses': [
                    email
                ],
                'CcAddresses': [],
                'BccAddresses': []
            },
            Message={
                'Subject': {
                    'Data': 'Seu certificado chegou!',
                    'Charset': 'UTF-8'
                },
                'Body': {
                    'Html': {
                        'Charset': 'UTF-8',
                        'Data': f'''
                            Olá, {nome}.<br><br>
                            Seu certificado de conclusão do curso <b>{curso}</b> está pronto.<br>
                            Clique <a href="{link}">aqui</a> para baixar ou acesse link abaixo.<br><br>
                            Link para download: <br>
                            {link}<br><br>
                            O link expira em {horas_expira} horas.
                        ''',
                    }
                }
            }
        )
    except Exception as erro:
        print(f'Não foi possível enviar o email para {nome}. Identidade não aprovada.')


def gerar_link(nome_bucket, nome_objeto, expira=3600):

    resposta = cliente_s3.generate_presigned_url(
        ClientMethod='get_object',
        Params={
            'Bucket': nome_bucket,
            'Key': nome_objeto
        },
        ExpiresIn=expira
    )

    return resposta


def gerar_certificado(nome, curso, horas, data):

    pdf = BytesIO()
    can = canvas.Canvas(pdf)
    can.setPageSize((720, 540))

    A4Land = (297 * mm, 210 * mm)
    can = canvas.Canvas(pdf, pagesize=A4Land)

    pageWidth = 720

    sub_texto_1 = f"Certificamos que {nome}".upper()
    sub_texto_1_width = stringWidth(sub_texto_1, 'RobotoCondensed-Regular', fonte)
    sub_texto_1_x = (pageWidth - sub_texto_1_width) / 2.0
    
    sub_texto_2 = f"concluiu o curso {curso},".upper()
    sub_texto_2_width = stringWidth(sub_texto_2, 'RobotoCondensed-Regular', fonte)
    sub_texto_2_x = (pageWidth - sub_texto_2_width) / 2.0
    
    sub_texto_3 = f"com duração de {horas} em {data}.".upper()
    sub_texto_3_width = stringWidth(sub_texto_3, 'RobotoCondensed-Regular', fonte)
    sub_texto_3_x = (pageWidth - sub_texto_3_width) / 2.0
    
    can.setFont("RobotoCondensed-Regular", fonte, leading=None)
    can.setFillColor("#000000")

    can.drawString(sub_texto_1_x, 300, sub_texto_1)
    can.drawString(sub_texto_2_x, 280, sub_texto_2)
    can.drawString(sub_texto_3_x, 260, sub_texto_3)

    can.drawString(450, 135, data)
    can.save()
    pdf.seek(0)

    novo_pdf = PdfReader(pdf)
    saida = PdfWriter()

    arquivo_modelo = open(modelo, 'rb')
    arquivo_leitura = PdfReader(arquivo_modelo)

    quantidade_paginas = len(arquivo_leitura.pages)

    for i in range(0, quantidade_paginas):
        pagina = arquivo_leitura.pages[i]
        pagina.merge_page(novo_pdf.pages[0])
        saida.add_page(pagina)

    return saida


def processar_pdf(nome, curso, horas, data, bucket):

    saida = gerar_certificado(nome, curso, horas, data)

    bytes_stream = BytesIO()
    saida.write(bytes_stream)
    bytes_stream.seek(0)

    # 4a68aa87-b80b-4692-9d52-259335df27cb 
    codigo = uuid.uuid4()

    arquivo_saida = f'certificados/{nome}-{codigo}.pdf'
    bucket.upload_fileobj(bytes_stream, arquivo_saida)

    print(f"PDF gerado para {nome}")
    return arquivo_saida
    

def obter_dados(caminho):
    arquivo = open(caminho, 'r')
    conteudo = arquivo.readlines()
    return conteudo


def verificar_emails(caminho):
    
    cliente_ses = boto3.client('ses')

    # r -> leitura
    # w -> escrita
    # a -> adicionar conteúdo
    arquivo = open(caminho, 'r')
    conteudo = arquivo.readlines()
    for indice, linha in enumerate(conteudo):
        if indice == 0:
            continue

        print(indice, linha)
        dados = linha.split(',')
        email = dados[1]

        resposta = cliente_ses.verify_email_identity(
            EmailAddress=email
        )
                
        print(indice)

